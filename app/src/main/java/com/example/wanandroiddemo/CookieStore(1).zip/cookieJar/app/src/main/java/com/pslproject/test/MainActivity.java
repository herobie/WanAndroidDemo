package com.pslproject.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;

import com.pslproject.test.databinding.ActivityMainBinding;
import com.pslproject.test.cookieStore.CookieJarImpl;
import com.pslproject.test.cookieStore.PersistentCookieStore;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    //使用ViewBinding
    private @NonNull ActivityMainBinding viewBindings;

    String text;
    String loginText;

    private Retrofit retrofit;
    private APIService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewBindings = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(viewBindings.getRoot());


        //初始化OkhttpClient（使用自定义的CookieJar来持久化Cookie，这里的自定义CookieJar是CookieJarImpl）
        // （这里的初始化就已经完成了对Cookie的持久化和Cookie的使用的 自动执行，所以在这次初始化后，无需对Cookie进行其他操作）
        OkHttpClient client = new OkHttpClient.Builder().cookieJar(new CookieJarImpl(new PersistentCookieStore(MainActivity.this))).build();
        //初始化Retrofit，导入刚刚初始化的client
        retrofit = new Retrofit.Builder().baseUrl("https://www.wanandroid.com/").client(client).build();
        apiService = retrofit.create(APIService.class);



        //点击登录按钮
        viewBindings.login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //登录操作，不用管，Cookie的持久化会自动进行,这里实现了显示登录信息
                String username = viewBindings.username.getText().toString();
                String password = viewBindings.password.getText().toString();
                Call<ResponseBody> call = apiService.login(username,password);

                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        ResponseBody body = response.body();
                        try {
                            loginText = body.string();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        Message message = new Message();
                        message.what = 2;
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {

                    }
                });
            }
        });

        //点击收藏按钮
        viewBindings.like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里实现了访问收藏功能，对Cookie的使用会自动进行
                Call<ResponseBody> call = apiService.like();
                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        ResponseBody body = response.body();
                        try {
                            text = body.string();
                            Log.e("e","msg:"+text);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        Message message = new Message();
                        message.what = 1;
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {

                    }
                });
            }
        });
    }


    //设置测试文本
    void setText(String text){
        viewBindings.textView.setText(text);
    }

    //异步设置文本用
    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 1 :
                    setText(text);
                    break;
                case 2 :
                    setText(loginText);
                    break;
            }
            return false;
        }
    });
}